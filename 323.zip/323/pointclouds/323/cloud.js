{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "",
    "points": 18696727,
    "boundingBox": {
        "lx": -82700.07549999999,
        "ly": -144800.5135,
        "lz": -0.4989999999999952,
        "ux": -82580.912,
        "uy": -144681.35,
        "uz": 118.66449999999512
    },
    "tightBoundingBox": {
        "lx": -82700.07549999999,
        "ly": -144800.51349999998,
        "lz": -0.4989999999999952,
        "ux": -82580.91249999999,
        "uy": -144687.87749999998,
        "uz": 18.181000000000006
    },
    "pointAttributes": [
        "POSITION_CARTESIAN",
        "COLOR_PACKED"
    ],
    "spacing": 1.0319862365722657,
    "scale": 0.001,
    "hierarchyStepSize": 5
}