{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "",
    "points": 192442,
    "boundingBox": {
        "lx": -82700.07549999999,
        "ly": -144800.51349999998,
        "lz": -0.4989999999999952,
        "ux": -82580.912,
        "uy": -144681.34999999999,
        "uz": 118.66449999999512
    },
    "tightBoundingBox": {
        "lx": -82608.12849999999,
        "ly": -144695.29649999998,
        "lz": 4.773959005888173e-15,
        "ux": -82598.9025,
        "uy": -144689.98849999999,
        "uz": 2.1630000000000049
    },
    "pointAttributes": [
        "POSITION_CARTESIAN",
        "COLOR_PACKED"
    ],
    "spacing": 1.0319862365722657,
    "scale": 0.001,
    "hierarchyStepSize": 5
}