{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "",
    "points": 20000,
    "boundingBox": {
        "lx": 39480053.0,
        "ly": -141817348.0,
        "lz": 30032.0,
        "ux": 39961223.0,
        "uy": -141336178.0,
        "uz": 511202.0
    },
    "tightBoundingBox": {
        "lx": 39884.703,
        "ly": -141620.162,
        "lz": 35.681,
        "ux": 39960.908,
        "uy": -141560.355,
        "uz": 47.174
    },
    "pointAttributes": [
        "POSITION_CARTESIAN",
        "COLOR_PACKED"
    ],
    "spacing": 4167.05419921875,
    "scale": 0.001,
    "hierarchyStepSize": 5
}