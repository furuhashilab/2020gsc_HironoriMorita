{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "",
    "points": 1893701,
    "boundingBox": {
        "lx": -71187.12275000003,
        "ly": -142816.43837000006,
        "lz": 20.09715000000001,
        "ux": -71038.48753000003,
        "uy": -142667.80315000006,
        "uz": 168.73236999999649
    },
    "tightBoundingBox": {
        "lx": -71187.12275000003,
        "ly": -142816.43837000006,
        "lz": 20.09715000000001,
        "ux": -71065.75946000003,
        "uy": -142667.80315000006,
        "uz": 43.56259000000002
    },
    "pointAttributes": [
        "POSITION_CARTESIAN",
        "COLOR_PACKED"
    ],
    "spacing": 1.2872188091278077,
    "scale": 0.001,
    "hierarchyStepSize": 5
}